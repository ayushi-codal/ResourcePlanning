// import { Component, OnInit } from '@angular/core';
import { Component, ViewChild, ViewChildren, QueryList, ChangeDetectorRef, OnInit } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { EmployeeService } from 'src/app/resources/employee.service';
@Component({
  selector: 'app-employeetable',
  templateUrl: './employeetable.component.html',
  styleUrls: ['./employeetable.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class EmployeetableComponent implements OnInit  {
  @ViewChild('outerSort', { static: true }) sort: MatSort;
  @ViewChildren('innerSort') innerSort: QueryList<MatSort>;
  @ViewChildren('innerTables') innerTables: QueryList<MatTable<Project>>;

  dataSource: MatTableDataSource<User>;
  usersData: User[] = [];
  users : any =[];
  columnsToDisplay = ['id','name', 'email'];
  innerDisplayedColumns = ['pId', 'pName', 'start','end','managers','technology'];
  expandedElement: User[] =[];
  constructor(
    private cd: ChangeDetectorRef, private es : EmployeeService
  ) { 
    
  }

  ngOnInit() {
    this.getData();
    USERS.forEach(user => {
      if (user.projects && Array.isArray(user.projects) && user.projects.length) {
        this.usersData = [...this.usersData, {...user, projects: new MatTableDataSource(user.projects)}];
      } else {
        this.usersData = [...this.usersData, user];
      }
    });
    this.dataSource = new MatTableDataSource(this.usersData);
    this.dataSource.sort = this.sort;
    this.es.getTaskss().subscribe((data : any[])=>{
        console.log(data);
        // this.use = data;
      //   console.log("pppppppppp",this.projects.length)
      })
  }
// }
  getData()
  {
    return this.es.getTaskss().subscribe((data: []) => {
      this.users = data;
      console.log(this.users)
    })
  }

  checkExpanded(element): boolean {
    let flag = false;
    this.expandedElement.forEach(e => {
      if(e === element) {
        flag = true;
        
      }
    });
    return flag;
  }
  toggleRow(element: User) {
    const index = this.expandedElement.indexOf(element);
    console.log(index);
    if(index === -1) {
        this.expandedElement.push(element);
    } else {
      this.expandedElement.splice(index,1);
    }
  }
  applyFilter(filterValue: string) {
    this.innerTables.forEach((table, index) => (table.dataSource as MatTableDataSource<Project>).filter = filterValue.trim().toLowerCase());
  }
}

export interface User {
  id : number;
  name: string;
  email: string;
  projects?: Project[] | MatTableDataSource<Project>;
}

export interface Project {
  pId: number;
  pName : string;
  start : string;
  end : string;
  managers : string;
  technology : any[];
 
}

export interface UserDataSource {
  id : number;
  name: string;
  email: string;
  projects?: MatTableDataSource<Project>;
}
const USERS: User[] = [
  
  {
    id : 2,
    name: "Ayushi Maru",
    email: "amaru@codal.com",
    projects: [
      {
        pId: 23,
        pName : "CATO",
        start : "2020/12/23",
        end : "2020/12/25",
        managers : "Manish Dariyani",
        technology : ["php","angular"]
      },
        {
          pId: 2,
          pName : "RP",
          start : "2020/12/23",
          end : "2020/12/25",
          managers : "Anil Shahu",
          technology : ["php","angular"]
        },
      
     
    ]
  },
  {
    id : 233,
    name: "Hani Joshi",
    email: "hjoshi@codal.com",
    projects: [
      {
        pId: 23,
        pName : "CATO",
        start : "2020/12/23",
        end : "2020/12/25",
        managers : "Manish Dariyani",
        technology : ["php","angular"]
      },
        {
          pId: 3,
          pName : "ML",
          start : "2020/12/23",
          end : "2020/12/25",
          managers : "Anil Shahu",
          technology : ["php","angular"]
        },
      
     
    ]
  }
 
];

  // items = [];
  // expandedIndex;
  // projects : any[]= [];
  // employees: any[] = [];
  //   constructor( private employeeService : EmployeeService){
  //     this.expandedIndex = -1; 
  // }
    
  //   ngOnInit()
  // {
  //   this.employeeService.getEmployees().subscribe((data : any[])=>{
  //     console.log(data);
  //     this.employees = data;
  // })
  // this.employeeService.getTasks().subscribe((data : any[])=>{
  //   console.log(data);
  //   this.projects = data;
  //   console.log("pppppppppp",this.projects.length)
  // })
  
  // }
  // Collaps(index: number) {  
  //   console.log("jiii" + index)
  //   this.expandedIndex = index === this.expandedIndex ? -1 : index;  
  
  //   }  
  //   }  


