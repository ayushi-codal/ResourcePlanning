import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import {ResorcePlanningApi} from 'src/common/swagger-providers/rp-api.provider';
@Injectable({
  providedIn: 'root'
})

export class DemoService {

  // Base url
  baseurl = 'src/common/swagger-providers/rp-api.provider.ts';

  constructor(private http: HttpClient) {this.loadEmployees(); }
  loadEmployees() {
    return this.http.get(this.baseurl);
  
}


}