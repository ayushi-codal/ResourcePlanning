import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GanttComponent } from './gantt/gantt.component';
import { EmployeetableComponent } from './employeetable/employeetable.component';
import { InMemoryWebApiModule, HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { DataService } from './data.service';
import { HttpClientModule } from '@angular/common/http';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { DemoComponent } from './demo/demo.component';
import { MatIconModule } from '@angular/material/icon'
import { DemoService } from 'src/app/resources/demo.service';
import { ResorcePlanningApi } from 'src/common/swagger-providers/rp-api.provider';
@NgModule({
  declarations: [GanttComponent, EmployeetableComponent, DemoComponent],
  imports: [
    CommonModule,
    InMemoryWebApiModule,
    HttpClientInMemoryWebApiModule,
    HttpClientModule,
    MatIconModule,
    InMemoryWebApiModule.forRoot(DataService),
    MatSortModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    ScrollingModule,
    MatChipsModule

  ],
  exports: [
    GanttComponent,
    EmployeetableComponent,
    DemoComponent
  ],
  providers: [DemoService, ResorcePlanningApi]
})
export class ResourcesModule { }
