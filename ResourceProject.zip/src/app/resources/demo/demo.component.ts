import { Component, OnInit } from '@angular/core';
import { DemoService } from 'src/app/resources/demo.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ResorcePlanningApi } from 'src/common/swagger-providers/rp-api.provider';
import { HeadersProvider } from 'headerProviders/header.provider';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {

  constructor(private test: ResorcePlanningApi) {
  }
  IssuesList: any = [];
  // SERVER_URL: 'src/common/swagger-providers/rp-api.provider.ts';
  // const localUrl = 'assets/data/smartphone.json';

  ngOnInit() {
    console.log('Innnn')
    this.getSmartphones();
  }

  getSmartphones() {
    console.log('API Before')
    const params = {
      id: 1,
      // "project_code": 1,
      // "employee_id": 1,
      // "updated_date": '2017-07-04*13:23:55',
      // "created_date": "2017-07-04*13:23:55"
    }
    // const GetEmployee  =this.test.GetRelationData(params,headers);
    // console.log(GetEmployee);
    console.log("params:", params)
    // console.log('HeadersProvider.headers', HeadersProvider.publicHeaders)
    // let headers = new HttpHeaders();

    let headers = new HttpHeaders();
    headers.append('X-Requested-With', 'XMLHttpRequest');
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/json');

    // this.addHeader('X-Requested-With', 'XMLHttpRequest');
    // this.addHeader('Accept', 'application/json');
    console.log('headers',headers)

    this.test.GetRelationData_1(params, headers).subscribe(

      (res: any) => {
        ''
        // console.log('API Inn')
        console.log('res:::::', res)
      },
      e => {
        console.log('e', e)
      })




  }


}
