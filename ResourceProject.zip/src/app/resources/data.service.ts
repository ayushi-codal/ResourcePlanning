import { Injectable } from '@angular/core';
import {InMemoryDbService} from 'angular-in-memory-web-api';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }
  createDb(){
    let api = [
      {
        "employee": {
          "id": "1",
          "employee_code": "220",
          "user_name": "sbhatt",
          "first_name": "soham",
          "last_name": "bhatt",
          "email": "sbhatt@codal.com",
          "phone": "7600810494",
          "date_of_birth": "1997-01-12",
          "gender": "male",
          "position": "jr.software dev",
          "hire_date": "2018-01-01",
          "slack_username": "UF5NUU2MU",
          "git_username": "",
          "leaving_date": null,
          "employee_deleted": "1",
          "created": "2018-06-29 04:29:57",
          "updated": "2019-10-24 11:10:00",
          "slack_notification": "0",
          "attendance_notification": "0",
          "slack_profile": "",
          "profile_image": null
        },
        "project": {
          "project_code": "1",
          "project_name": "Project Planning",
          "start_date": "2020-02-01",
          "end_date": "2020-04-01",
          "project_lead": "1",
          "project_technology": "PHP",
          "is_deleted": "0",
          "update_date": "2020-03-09 00:58:31",
          "create_date": "2020-02-25 03:56:07"
        },
        "employeeprojectrelation": {
          "id": "1",
          "employee_id": "1",
          "project_code": "1",
          "created_date": "2020-03-03 14:30:58",
          "updated_date": "2020-03-03 02:31:20"
        }
      },
      {
        "employee": {
          "id": "1",
          "employee_code": "220",
          "user_name": "sbhatt",
          "first_name": "soham",
          "last_name": "bhatt",
          "email": "sbhatt@codal.com",
          "phone": "7600810494",
          "date_of_birth": "1997-01-12",
          "gender": "male",
          "position": "jr.software dev",
          "hire_date": "2018-01-01",
          "slack_username": "UF5NUU2MU",
          "git_username": "",
          "leaving_date": null,
          "employee_deleted": "1",
          "created": "2018-06-29 04:29:57",
          "updated": "2019-10-24 11:10:00",
          "slack_notification": "0",
          "attendance_notification": "0",
          "slack_profile": "",
          "profile_image": null
        },
        "project": {
          "project_code": "3",
          "project_name": "CRM",
          "start_date": "2020-02-01",
          "end_date": "2020-04-01",
          "project_lead": "1",
          "project_technology": "PHP",
          "is_deleted": "0",
          "update_date": "2020-03-09 00:58:48",
          "create_date": "2020-02-26 23:32:31"
        },
        "employeeprojectrelation": {
          "id": "1",
          "employee_id": "1",
          "project_code": "1",
          "created_date": "2020-03-03 14:30:58",
          "updated_date": "2020-03-03 02:31:20"
        }
      },
      {
        "employee": {
          "id": "1",
          "employee_code": "220",
          "user_name": "sbhatt",
          "first_name": "soham",
          "last_name": "bhatt",
          "email": "sbhatt@codal.com",
          "phone": "7600810494",
          "date_of_birth": "1997-01-12",
          "gender": "male",
          "position": "jr.software dev",
          "hire_date": "2018-01-01",
          "slack_username": "UF5NUU2MU",
          "git_username": "",
          "leaving_date": null,
          "employee_deleted": "1",
          "created": "2018-06-29 04:29:57",
          "updated": "2019-10-24 11:10:00",
          "slack_notification": "0",
          "attendance_notification": "0",
          "slack_profile": "",
          "profile_image": null
        },
        "project": {
          "project_code": "4",
          "project_name": "CP",
          "start_date": "2020-01-01",
          "end_date": "2020-12-31",
          "project_lead": "1",
          "project_technology": "php",
          "is_deleted": "1",
          "update_date": "2020-03-09 00:58:59",
          "create_date": "2020-02-28 04:17:44"
        },
        "employeeprojectrelation": {
          "id": "1",
          "employee_id": "1",
          "project_code": "1",
          "created_date": "2020-03-03 14:30:58",
          "updated_date": "2020-03-03 02:31:20"
        }
      }
    ]
    let taskss = [{
      id : 2,
      name: "Ayushi Maru",
      email: "amaru@codal.com",
      projects: [
        {
          pId: 23,
          pName : "CATO",
          start : "2020/12/23",
          end : "2020/12/25",
          managers : "Manish Dariyani",
          technology : ["php","angular"]
        },
          {
            pId: 2,
            pName : "RP",
            start : "2020/12/23",
            end : "2020/12/25",
            managers : "Anil Shahu",
            technology : ["php","angular"]
          },
        
       
      ]
    },
    {
      id : 233,
      name: "Hani Joshi",
      email: "hjoshi@codal.com",
      projects: [
        {
          pId: 23,
          pName : "CATO",
          start : "2020/12/23",
          end : "2020/12/25",
          managers : "Manish Dariyani",
          technology : ["php","angular"]
        },
          {
            pId: 3,
            pName : "ML",
            start : "2020/12/23",
            end : "2020/12/25",
            managers : "Anil Shahu",
            technology : ["php","angular"]
          },
        
       
      ]
    }
   ]

    let  employeeDetails =  [
     {  id:  1,  name:  'Ayushi Maru' },
     {
       id : 2, name : 'Ekta Gandhi'},
       { id : 4 , name : 'Het Rachh'},
       { id : 8 , name: 'Hani Joshi'}
     ];
  
      let tasks = [{
        id: '8',
        name: 'CATO',
        ename : ['Ayushi Maru','Ekta Gandhi'],
        start: '2020-11-28',
        end: '2020-12-31',
        progress: 20,
        manager :'Manish Dariyani',
        dependencies: null,
        project : [{
          id: 'cad',
          name : 'asd',
          start : '2020-11-23',
          end : '2020-12-22',
          progress : 90,
          dependencies : null
        }]
        
      },
      {
        id: 'Task 2',
        name: 'Resource Planning',
        ename : ['Ayushi Maru'],
        start: '2020-10-28',
        end: '2020-12-31',
        progress: 20,
        manager :'Anil Shahu',
        dependencies: null

      },
      {
      id: 'Task 3',
      name: 'Redesign website',
      ename : ['Het Rachh', 'Ekta Gandhi', 'Hani Joshi'],
      start: '2020-12-28',
      end: '2021-01-31',
      progress: 20,
      manager :'Priyank Patel',
      dependencies: null
      }
    ]
 
    return {employeeDetails,tasks,taskss, api};
 
   }
}
