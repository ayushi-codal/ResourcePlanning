import { Component, NgZone, ViewChild, ElementRef, OnInit } from "@angular/core";
import * as moment from 'moment';
import { EmployeeService} from 'src/app/resources/employee.service';
import {Gantt} from 'node_modules/frappe-gantt/src/index.js';
@Component({
  selector: 'app-gantt',
  templateUrl: './gantt.component.html',
  styleUrls: ['./gantt.component.css']
})
export class GanttComponent  {
  @ViewChild('gantt',{static: true}) gantt: ElementRef;
  dataSource: Object;
  title: string;
  chart: any;
  tasks : any;
  array : any[];
  constructor( private es : EmployeeService) {  
  }
  ngAfterViewInit(){
    
    this.es.getTasks().subscribe((data : any[])=>{
    
      console.log(data);
      this.tasks = data;
      console.log(this.tasks)
    this.gantt.nativeElement = new Gantt(this.gantt.nativeElement, this.tasks, {
      header_height: 50,
      column_width: 30,
      step: 24,
      view_modes: ['Quarter Day', 'Half Day', 'Day', 'Week', 'Month'],
      bar_height: 20,
      bar_corner_radius: 3,
      arrow_curve: 5,
      padding: 18,
      view_mode: 'Month',   
      date_format: 'DD-MM-YYYY',
      on_click: function (task) {
				console.log(task);
			},
			on_date_change: function(task, start, end) {
				console.log(task, start, end);
			},
			on_progress_change: function(task, progress) {
				console.log(task, progress);
			},
			on_view_change: function(mode) {
				console.log(mode);
			},
			language: 'en'
    })
  })
  }
}



