module.exports = {
  SWAGGER_URL: 'http://192.168.1.141',
};